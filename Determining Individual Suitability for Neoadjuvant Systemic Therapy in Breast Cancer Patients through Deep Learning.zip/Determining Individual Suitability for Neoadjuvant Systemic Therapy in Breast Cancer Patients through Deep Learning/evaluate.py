import warnings

import numpy as np
import pandas as pd
import torch
from pycox.evaluation import EvalSurv
from sksurv.ensemble import RandomSurvivalForest, GradientBoostingSurvivalAnalysis
from sksurv.linear_model import CoxPHSurvivalAnalysis, CoxnetSurvivalAnalysis
from sksurv.util import Surv

from models.Deepsurv import DeepSurv
from models.bites.analyse.analyse_utils import get_C_Index_BITES, get_ITE_BITES, get_ITE_DeepSurvT, \
    get_C_Index_DeepSurv, analyse_randomized_test_set, get_ITE_sksurv
from models.bites.model.BITES_base import BITES
from models.utils import df_totrain, get_ITE_byRMST, deepsurv_dftotrain, get_ITEbyrmstfordeepsurv, sksurv_getsurvivaldf
from utils.ITE import save_rec

warnings.filterwarnings('ignore')


def eval_bites(root=None, iterations=500, save=True, ITE_method='tar',
               time_horizon=119):
    assert ITE_method in ['tar', 'rmst']
    model = BITES(46, [256, 100], [100, 64], 1)
    model.load_state_dict(torch.load('params/bites.pth'))
    df = pd.read_csv(root)
    X, Y, T, E = df_totrain(df)
    model = model.cpu()
    a = model.compute_baseline_hazards(input=X, target=[Y, E, T])
    if iterations is not None:
        c_values, c_values0, c_values1 = [], [], []
        b_values, b_values0, b_values1 = [], [], []
        print(f'Starts bootstrap indicators with {iterations} iterations')
        for i in range(iterations):
            dfx = df.sample(frac=.5)
            dft, dfy, dfe = dfx['treatment'].values, dfx['time'].values, dfx['event'].values
            dfx = dfx.drop(columns=['treatment', 'event', 'time']).values
            surv0, surv1 = model.predict_surv_df(dfx, dft)
            surv = pd.concat([surv0, surv1], axis=1)
            surv = surv.interpolate('index')
            surv = surv.sort_index(ascending=True)
            ev0 = EvalSurv(surv0, dfy[dft == 0], dfe[dft == 0], censor_surv='km')
            ev1 = EvalSurv(surv1, dfy[dft == 1], dfe[dft == 1], censor_surv='km')
            ev = EvalSurv(surv, np.append(dfy[dft == 0], dfy[dft == 1]),
                          np.append(dfe[dft == 0], dfe[dft == 1]),
                          censor_surv='km')
            C_index, C_index0, C_index1 = ev.concordance_td(), ev0.concordance_td(), ev1.concordance_td()
            time_grid = np.linspace(dfy.min(), dfy.max(), 100)
            brier, brier0, brier1 = ev.integrated_brier_score(time_grid), ev0.integrated_brier_score(
                time_grid), ev1.integrated_brier_score(time_grid)
            b_values.append(brier), b_values0.append(brier0), b_values1.append(brier1)
            c_values.append(C_index), c_values0.append(C_index0), c_values1.append(C_index1)
        print(
            f'c-index0:{np.percentile(c_values0, (50, 2.5, 97.5))}, c-index1:{np.percentile(c_values1, (50, 2.5, 97.5))}, '
            f'c-index_total:{np.percentile(c_values, (50, 2.5, 97.5))}')
        print(
            f'brier0:{np.percentile(b_values0, (50, 2.5, 97.5))}, brier1:{np.percentile(b_values1, (50, 2.5, 97.5))}, '
            f'brier_total:{np.percentile(b_values, (50, 2.5, 97.5))}')
    C_index, C_index0, C_index1 = get_C_Index_BITES(model, X.detach().numpy(), Y.detach().numpy(),
                                                    E.detach().numpy(), T.detach().numpy())
    if ITE_method == 'rmst':
        ITE, correct_predicted_probability = get_ITE_byRMST(model, X, T, time_horizon=time_horizon)
    elif ITE_method == 'tar':
        ITE, correct_predicted_probability = get_ITE_BITES(model, X, T)
    print(f'Using {ITE_method} to calculate ITE!')
    save_rec(ITE, df, save=save, test=False)


def eval_deepsurv(root=None, iterations=500, save=True, ITE_method='tar',
                  param0=None, param1=None, time_horizon=119):
    assert ITE_method in ['tar', 'rmst', 'point']
    model0, model1 = DeepSurv(46, [128, 90, 90]), DeepSurv(46, [128, 90, 90])
    model0.load_state_dict(torch.load(param0))
    model1.load_state_dict(torch.load(param1))
    df = pd.read_csv(root)
    X0, Y0, E0, X1, Y1, E1, X, T = deepsurv_dftotrain(df)
    a, b = model0.compute_baseline_hazards(X0, [Y0, E0]), model1.compute_baseline_hazards(X1, [Y1, E1])
    if iterations is not None:
        c_values0, c_values1 = [], []
        b_values0, b_values1 = [], []
        print(f'Starts bootstrap indicators with {iterations} iterations')
        for i in range(iterations):
            dfbt = df.sample(frac=.5)
            dfx0, dfy0, dfe0, dfx1, dfy1, dfe1, _, _ = deepsurv_dftotrain(dfbt)
            surv0, surv1 = model0.predict_surv_df(dfx0), model1.predict_surv_df(dfx1)
            ev0 = EvalSurv(surv0, dfy0.numpy(), dfe0.numpy(), censor_surv='km')
            ev1 = EvalSurv(surv1, dfy1.numpy(), dfe1.numpy(), censor_surv='km')
            C_index0, C_index1 = ev0.concordance_td(), ev1.concordance_td()
            time_grid0, time_grid1 = np.linspace(Y0.min(), Y0.max(), 100), np.linspace(Y1.min(), Y1.max(), 100)
            brier0, brier1 = ev0.integrated_brier_score(time_grid0), ev1.integrated_brier_score(time_grid1)
            b_values0.append(brier0), b_values1.append(brier1)
            c_values0.append(C_index0), c_values1.append(C_index1)
        print(
            f'c-index0:{np.percentile(c_values0, (50, 2.5, 97.5))}, c-index1:{np.percentile(c_values1, (50, 2.5, 97.5))}')
        print(f'brier0:{np.percentile(b_values0, (50, 2.5, 97.5))}, brier1:{np.percentile(b_values1, (50, 2.5, 97.5))}')
    if ITE_method == 'tar':
        ITE, correct_predicted_probability = get_ITE_DeepSurvT(model0, model1, X.numpy(), T.numpy())
    elif ITE_method == 'rmst':
        ITE, correct_predicted_probability = get_ITEbyrmstfordeepsurv(model0, model1, X.numpy(), T.numpy(),
                                                                      time_horizon=time_horizon)
    elif ITE_method == 'point':
        ITE = model1.predict_numpy(X) - model0.predict_numpy(X)
    print(f'Using {ITE_method} to calculate ITE!')
    save_rec(ITE, df, save=save)
    analyse_randomized_test_set(ITE, df['time'].values, df['event'].values, df['treatment'].values)
    C_index0, _, _ = get_C_Index_DeepSurv(model0, X0.numpy(), Y0.numpy(),
                                          E0.numpy())
    C_index1, _, _ = get_C_Index_DeepSurv(model1, X1.numpy(), Y1.numpy(),
                                          E1.numpy())


def eval_sksurv_treated(train_root=None, test_root=None, iterations=500,
                        save=True, ITE_method='tar',
                        method='cph', target=['time', 'event', 'treatment'], time_horizon=190):
    if method == 'cph':
        model0, model1 = CoxPHSurvivalAnalysis(alpha=1e-4), CoxPHSurvivalAnalysis(alpha=1e-4)
    elif method == 'rsf':
        model0, model1 = RandomSurvivalForest(random_state=18), RandomSurvivalForest(random_state=18)
    elif method == 'gbst':
        model0, model1 = GradientBoostingSurvivalAnalysis(), GradientBoostingSurvivalAnalysis()
    elif method == 'coxnet':
        model0, model1 = CoxnetSurvivalAnalysis(fit_baseline_model=True), CoxnetSurvivalAnalysis(
            fit_baseline_model=True)
    df_train = pd.read_csv(train_root)

    df_train = df_train.fillna(df_train.median())
    df_train0 = df_train[df_train['treatment'] == 0]
    df_train1 = df_train[df_train['treatment'] == 1]
    df_test = pd.read_csv(test_root)

    df_test0 = df_test[df_test['treatment'] == 0]
    df_test1 = df_test[df_test['treatment'] == 1]
    X_train0, y_train0 = df_train0.drop(columns=target), Surv.from_dataframe('event', 'time', df_train0)
    X_train1, y_train1 = df_train1.drop(columns=target), Surv.from_dataframe('event', 'time', df_train1)
    X_test, y_test = df_test.drop(columns=target), Surv.from_dataframe('event', 'time', df_test)
    model0.fit(X_train0, y_train0)
    model1.fit(X_train1, y_train1)
    if iterations is not None:
        c_values0, c_values1 = [], []
        b_values0, b_values1 = [], []
        print(f'Starts bootstrap indicators with {iterations} iterations')
        for i in range(iterations):
            dfb0, dfb1 = df_test0.sample(frac=.5), df_test1.sample(frac=.5)
            yb0, yb1 = Surv.from_dataframe('event', 'time', dfb0), Surv.from_dataframe('event', 'time', dfb1)
            xb0, xb1 = dfb0.drop(columns=target), dfb1.drop(columns=target)
            surv0, surv1 = sksurv_getsurvivaldf(xb0, model=model0), sksurv_getsurvivaldf(xb1, model=model1)
            ev0 = EvalSurv(surv0, dfb0[target[0]].values, dfb0[target[1]].values, censor_surv='km')
            ev1 = EvalSurv(surv1, dfb1[target[0]].values, dfb1[target[1]].values, censor_surv='km')
            C_index0, C_index1 = ev0.concordance_td(), ev1.concordance_td()
            time_grid0, time_grid1 = np.linspace(dfb0[target[0]].values.min(), dfb0[target[0]].values.max(), 100), \
                np.linspace(dfb1[target[0]].values.min(), dfb1[target[0]].values.max(), 100)
            brier0, brier1 = ev0.integrated_brier_score(time_grid0), ev1.integrated_brier_score(time_grid1)
            b_values0.append(brier0), b_values1.append(brier1)
            c_values0.append(C_index0), c_values1.append(C_index1)
        print(
            f'c-index0:{np.percentile(c_values0, (50, 2.5, 97.5))}, c-index1:{np.percentile(c_values1, (50, 2.5, 97.5))}')
        print(f'brier0:{np.percentile(b_values0, (50, 2.5, 97.5))}, brier1:{np.percentile(b_values1, (50, 2.5, 97.5))}')
    ITE, correct_predicted_probability = get_ITE_sksurv(model0, model1, df_test, method=ITE_method,
                                                        time_horizon=time_horizon)
    print(f'Using {ITE_method} to calculate ITE!')
    save_rec(ITE, df_test, save=save)
    analyse_randomized_test_set(ITE, df_test['time'].values, df_test['event'].values, df_test['treatment'].values)


if __name__ == '__main__':
    torch.manual_seed(18)
