import pandas as pd

from models.bites.model.BITES_base import BITES
from utils.load import df_totrain

if __name__ == '__main__':
    X, time, event, treatment = df_totrain(pd.read_csv(None))
    model = BITES(X.shape[1], [256, 100], [100, 64], 1)
    out = model(X, treatment)
