import numpy as np
import pandas as pd
import torch
from auton_survival import metrics
from lifelines import KaplanMeierFitter
from lifelines.plotting import add_at_risk_counts
from lifelines.utils import concordance_index
from sklearn.metrics._ranking import auc
from sksurv.ensemble import RandomSurvivalForest
from sksurv.linear_model import CoxPHSurvivalAnalysis
from sksurv.metrics import integrated_brier_score, cumulative_dynamic_auc
from sklearn.utils import shuffle

def sksurv_getsurvivaldf(X_val, X_train=None, y_train=None, model='cph'):
    """ X_train / X_val is a pd.Dataframe contains covariates
    y_train/y_val is a Surv object e.g. Surv("event", "time", df) """
    if model in ['cph', 'rsf']:  # cox & random survival forest
        if model == 'cph':
            model = CoxPHSurvivalAnalysis()
        elif model == 'rsf':
            model = RandomSurvivalForest(random_state=18)
        model.fit(X_train, y_train)
    a = model.predict_survival_function(X_val)  # [num_samples, ]
    survival_p = []
    for i, each in enumerate(a):
        survival_p.append(each.y)
    survival_p = list(map(list, zip(*survival_p)))  # 转置
    time_index = pd.Series(a[0].x, name='time')
    survival_p = pd.DataFrame(survival_p).set_index(time_index)
    return survival_p

def __get_restricted_area(km_estimate, horizon):
    """Compute area under the Kaplan Meier curve (mean survival time) restricted by a specified
    time horizion.

    Parameters
    -----------
    km_estimate : Fitted Kaplan Meier estimator.
    horizon : float
        The time horizon at which to compare the survival curves.
        Must be specified for metric 'restricted_mean' and 'survival_at'.
        For 'hazard_ratio' this is ignored.

    Returns
    -----------
    float : Area under the Kaplan Meier curve (mean survival time).
    @ zez: KM_estimate is a pd.Dataframe, e.g. model.predict_surv_df
    """

    # x = km_estimate.survival_function_.index.values
    x = km_estimate.index
    # horizon_list = [horizon for i in range(len(x))]
    idx = [i < horizon for i in x]
    # y = km_estimate.survival_function_.KM_estimate.values[idx].tolist()
    y = km_estimate.values[idx]
    # y = y + [float(km_estimate.iloc[:, i][find_nearest_index(km_estimate.index.values, horizon)])]
    ite = auc(x[idx], y)  # sklearn.metrics._ranking.auc
    return ite

def get_ITE_BITES(model, X, treatment,method='tar', best_treatment=None, death_probability=0.5, time_horizon=60):
    def find_nearest_index(array, value):
        idx = (np.abs(array - value)).argmin()
        return idx
    assert method in ['rmst','tar']
    surv0, surv1 = model.predict_surv_df(X, treatment)  # actual situation
    surv0_cf, surv1_cf = model.predict_surv_counterfactual_df(X, treatment)  # "What if" situation
    """Find factual and counterfactual prediction: Value at 50% survival probability"""
    pred0 = np.zeros(surv0.shape[1])
    pred0_cf = np.zeros(surv0.shape[1])
    if method == 'tar':
        for i in range(surv0.shape[1]):
            pred0[i] = surv0.axes[0][find_nearest_index(surv0.iloc[:, i].values, death_probability)]   # median survival time
            pred0_cf[i] = surv0_cf.axes[0][find_nearest_index(surv0_cf.iloc[:, i].values, death_probability)]
        ITE0 = pred0_cf - pred0
    elif method == 'rmst':
        for i in range(surv0.shape[1]):  # each sample
            pred0[i] = __get_restricted_area(surv0.iloc[:, i], horizon=time_horizon)
            pred0_cf[i] = __get_restricted_area(surv0_cf.iloc[:, i], horizon=time_horizon)
        ITE0 = pred0_cf - pred0
    pred1 = np.zeros(surv1.shape[1])
    pred1_cf = np.zeros(surv1.shape[1])
    if method == 'tar':
        for i in range(surv1.shape[1]):
            pred1[i] = surv1.axes[0][find_nearest_index(surv1.iloc[:, i].values, death_probability)]
            pred1_cf[i] = surv1_cf.axes[0][find_nearest_index(surv1_cf.iloc[:, i].values, death_probability)]
        ITE1 = pred1 - pred1_cf
    elif method == 'rmst':
        for i in range(surv1.shape[1]):
            pred1[i] = __get_restricted_area(surv1.iloc[:, i], horizon=time_horizon)
            pred1_cf[i] = __get_restricted_area(surv1_cf.iloc[:, i], horizon=time_horizon)
        ITE1 = pred1 - pred1_cf
    ITE = np.zeros(X.shape[0])
    k, j = 0, 0
    for i in range(X.shape[0]):
        if treatment[i] == 0:
            ITE[i] = ITE0[k]
            k = k + 1
        else:
            ITE[i] = ITE1[j]
            j = j + 1
    correct_predicted_probability = None
    if best_treatment is not None:
        correct_predicted_probability = np.sum(best_treatment == (ITE > 0) * 1) / best_treatment.shape[0]
        print('Fraction best choice: ' + str(correct_predicted_probability))
    return ITE, correct_predicted_probability

def get_ITE_deepsurv(model0, model1, X, treatment,method='tar', best_treatment=None, time_horizon=60., death_probability=0.5):
    assert method in ['rmst', 'tar']
    mask0 = treatment == 0
    mask1 = treatment == 1
    X0 = X[mask0]
    X1 = X[mask1]
    surv0 = model0.predict_surv_df(X0)
    surv0_cf = model1.predict_surv_df(X0)
    surv1 = model1.predict_surv_df(X1)
    surv1_cf = model0.predict_surv_df(X1)
    def find_nearest_index(array, value):
        idx = (np.abs(array - value)).argmin()
        return idx
    """Find factual and counterfactual prediction: Value at 50% survival probability"""
    pred0 = np.zeros(surv0.shape[1])
    pred0_cf = np.zeros(surv0.shape[1])
    if method == 'rmst':
        for i in range(surv0.shape[1]):
            pred0[i] = __get_restricted_area(surv0.iloc[:, i], horizon=time_horizon)
            pred0_cf[i] = __get_restricted_area(surv0_cf.iloc[:, i], horizon=time_horizon)
        ITE0 = pred0_cf - pred0
    elif method == 'tar':
        for i in range(surv0.shape[1]):
            pred0[i] = surv0.axes[0][find_nearest_index(surv0.iloc[:, i].values, death_probability)]   # median survival time
            pred0_cf[i] = surv0_cf.axes[0][find_nearest_index(surv0_cf.iloc[:, i].values, death_probability)]
        ITE0 = pred0_cf - pred0

    pred1 = np.zeros(surv1.shape[1])
    pred1_cf = np.zeros(surv1.shape[1])
    if method == 'rmst':
        for i in range(surv1.shape[1]):
            pred1[i] = __get_restricted_area(surv1.iloc[:, i], horizon=time_horizon)
            pred1_cf[i] = __get_restricted_area(surv1_cf.iloc[:, i], horizon=time_horizon)
        ITE1 = pred1 - pred1_cf
    elif method == 'tar':
        for i in range(surv1.shape[1]):
            pred1[i] = surv1.axes[0][find_nearest_index(surv1.iloc[:, i].values, death_probability)]
            pred1_cf[i] = surv1_cf.axes[0][find_nearest_index(surv1_cf.iloc[:, i].values, death_probability)]
        ITE1 = pred1 - pred1_cf
    ITE = np.zeros(X.shape[0])
    k, j = 0, 0
    for i in range(X.shape[0]):
        if treatment[i] == 0:
            ITE[i] = ITE0[k]
            k = k + 1
        else:
            ITE[i] = ITE1[j]
            j = j + 1

    correct_predicted_probability=None
    if best_treatment is not None:
        correct_predicted_probability=np.sum(best_treatment==(ITE>0)*1)/best_treatment.shape[0]
        print('Fraction best choice: ' + str(correct_predicted_probability))
    return ITE, correct_predicted_probability

def get_ITE_sksurv(model0, model1,df, best_treatment=None, death_probability=0.5, method='tar', time_horizon=60.):
    assert method in ['rmst', 'tar']
    def find_nearest_index(array, value):
        idx = (np.abs(array - value)).argmin()
        return idx

    treatment = df['treatment'].values
    X0 = df[df['treatment']==0].drop(columns=['time','event','treatment'])
    X1 = df[df['treatment']==1].drop(columns=['time','event','treatment'])
    surv0 = sksurv_getsurvivaldf(X0,model=model0)
    surv0_cf = sksurv_getsurvivaldf(X0,model=model1)
    surv1 = sksurv_getsurvivaldf(X1,model=model1)
    surv1_cf = sksurv_getsurvivaldf(X1,model=model0)
    pred0 = np.zeros(surv0.shape[1])
    pred0_cf = np.zeros(surv0.shape[1])
    if method == 'tar':
        for i in range(surv0.shape[1]):
            pred0[i] = __get_restricted_area(surv0.iloc[:, i], horizon=time_horizon)
            pred0_cf[i] = __get_restricted_area(surv0_cf.iloc[:, i], horizon=time_horizon)
    elif method == 'rmst':
        for i in range(surv0.shape[1]):
            pred0[i] = surv0.axes[0][find_nearest_index(surv0.iloc[:, i].values, death_probability)]
            pred0_cf[i] = surv0_cf.axes[0][find_nearest_index(surv0_cf.iloc[:, i].values, death_probability)]
    ITE0 = pred0_cf - pred0
    pred1 = np.zeros(surv1.shape[1])
    pred1_cf = np.zeros(surv1.shape[1])
    if method == 'tar':
        for i in range(surv1.shape[1]):
            pred1[i] = surv1.axes[0][find_nearest_index(surv1.iloc[:, i].values, death_probability)]
            pred1_cf[i] = surv1_cf.axes[0][find_nearest_index(surv1_cf.iloc[:, i].values, death_probability)]
    elif method == 'rmst':
        pred1[i] = __get_restricted_area(surv1.iloc[:, i], horizon=time_horizon)
        pred1_cf[i] = __get_restricted_area(surv1_cf.iloc[:, i], horizon=time_horizon)
    ITE1 = pred1 - pred1_cf

    ITE = np.zeros(df.shape[0])
    k, j = 0, 0
    for i in range(df.shape[0]):
        if treatment[i] == 0:
            ITE[i] = ITE0[k]
            k = k + 1
        else:
            ITE[i] = ITE1[j]
            j = j + 1
    correct_predicted_probability = None
    if best_treatment is not None:
        correct_predicted_probability = np.sum(best_treatment == (ITE > 0) * 1) / best_treatment.shape[0]
        print('Fraction best choice: ' + str(correct_predicted_probability))

    return ITE, correct_predicted_probability

def save_rec(ITE, df, save_path='br_rec.csv', save=False, time_horizon=60, test=True):
    """ save a dataframe with rec
    and calculate ITE """
    df = df.reset_index(drop=True)  # frac后必须reset_index
    rec = []
    for i in range(len(ITE)):
        if ITE[i] > 0 and df['treatment'][i] == 1:
            r = True
        elif ITE[i] <= 0 and df['treatment'][i] == 0:
            r = True
        else:
            r = False
        rec.append(r)
    if test:

        RMST = metrics.survival_diff_metric(metric='restricted_mean', outcomes=df,
                                            treatment_indicator=np.asarray(rec), horizon=time_horizon)  # rmst1 - rmst0
        survival_at = metrics.survival_diff_metric(metric='survival_at', outcomes=df,
                                                   treatment_indicator=np.asarray(rec), horizon=time_horizon)
        print(f'RMST is: {RMST}, survival at time is: {survival_at}')

    if save:
        ITE = pd.DataFrame(ITE, columns=['ITE'])
        df_new = pd.concat([df, ITE], axis=1)
        df_new.to_csv(save_path, index=False)

        print(f'Successfully restore csv_file with recommendation in {save_path}')

def plot_kaplanmeier(outcomes, groups=None, plot_counts=False, **kwargs):

  """Plot a Kaplan-Meier Survival Estimator stratified by groups.
  Parameters
  ----------
  outcomes: pandas.DataFrame
    a pandas dataframe containing the survival outcomes. The index of the
    dataframe should be the same as the index of the features dataframe.
    Should contain a column named 'time' that contains the survival time and
    a column named 'event' that contains the censoring status.
    \( \delta_i = 1 \) if the event is observed.
  groups: pandas.Series
    a pandas series containing the groups to stratify the Kaplan-Meier
    estimates by.
  plot_counts: bool
    if True, plot the number of at risk and censored individuals in each group.
  """

  if groups is None:
    groups = np.array([1]*len(outcomes))

  curves = {}

  from matplotlib import pyplot as plt

  ax = plt.subplot(111)

  for group in sorted(set(groups)):
    if pd.isna(group): continue

    curves[group] = KaplanMeierFitter().fit(outcomes[groups==group]['time'],
                                            outcomes[groups==group]['event'],)
    ax = curves[group].plot(label=group, ax=ax, **kwargs)

  if plot_counts:
    add_at_risk_counts(iter([curves[group] for group in curves]), ax=ax)
  plt.show()

  return ax


